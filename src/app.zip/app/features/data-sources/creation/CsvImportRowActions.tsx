import { useEffect, useMemo, useState } from "react";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/app/components/ui/tooltip";
import { LuxiaAiButton } from "@/app/components/LuxiaAiButton";
import {
  CSV_COLUMN_TYPES,
  selectedColumnType,
  type CsvImportFileDraft,
} from "./csv";
import type { CsvColumnDraft, CsvValidationIssue, CsvValidationSummary } from "./types";
import {
  proposeCsvSimilarRepairs,
  proposeCsvValueRepair,
  type CsvAiSimilarRepairSuccess,
  type CsvAiValueRepairSuccess,
} from "./csvAi";

export const EXCLUDE_ROW_HINT =
  "Exclude this row from import. You can restore it before creating the Data Source.";
export const SCHEMA_PREVIEW_ROW_LIMIT = 20;

type IssueResolution = "open" | "skipped" | "resolved";
export type DisplayCsvIssue = CsvValidationIssue & { resolution: IssueResolution };

function truncateCsvCell(value: string, max = 36): string {
  const collapsed = value.replace(/\s+/g, " ").trim();
  if (!collapsed) return "";
  if (collapsed.length <= max) return collapsed;
  return `${collapsed.slice(0, Math.max(1, max - 1))}…`;
}

export function issueRowSurface(resolution: IssueResolution): {
  background: string;
  statusLabel: string;
  statusColor: string;
} {
  if (resolution === "skipped") {
    return {
      background: "var(--luxia-warning-10)",
      statusLabel: "Excluded",
      statusColor: "var(--luxia-warning-90)",
    };
  }
  if (resolution === "resolved") {
    return {
      background: "var(--luxia-success-10)",
      statusLabel: "Resolved",
      statusColor: "var(--luxia-success-70)",
    };
  }
  return {
    background: "var(--luxia-opacity-error-08)",
    statusLabel: "Error",
    statusColor: "var(--luxia-error-70)",
  };
}

export function ExcludeRowButton({ onExclude }: { onExclude: () => void }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          type="button"
          variant="secondary"
          size="compact"
          onClick={onExclude}
          aria-label={`Exclude row. ${EXCLUDE_ROW_HINT}`}
        >
          Exclude row
        </Button>
      </TooltipTrigger>
      <TooltipContent>{EXCLUDE_ROW_HINT}</TooltipContent>
    </Tooltip>
  );
}

function InlineValueFix({
  original,
  expected,
  onCancel,
  onSave,
}: {
  original: string;
  expected: string;
  onCancel: () => void;
  onSave: (value: string) => string | null;
}) {
  const [draft, setDraft] = useState(original);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setDraft(original);
    setError(null);
  }, [original]);

  function save() {
    const message = onSave(draft);
    setError(message);
  }

  return (
    <div className="min-w-[12rem] space-y-2">
      <Input
        value={draft}
        onChange={(event) => {
          setDraft(event.target.value);
          setError(null);
        }}
        onKeyDown={(event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            save();
          }
          if (event.key === "Escape") {
            event.preventDefault();
            onCancel();
          }
        }}
        autoComplete="off"
        aria-label="Corrected value"
        aria-invalid={Boolean(error)}
        className="h-8"
        autoFocus
      />
      {error ? (
        <p className="luxia-type-caption" style={{ color: "var(--luxia-error-70)" }} role="alert">
          {error}
        </p>
      ) : (
        <p className="luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
          Expected: {expected}
        </p>
      )}
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant="outline" size="compact" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="button" variant="primary" size="compact" onClick={save}>
          Save
        </Button>
      </div>
    </div>
  );
}

function AiSuggestionReview({
  original,
  suggestion,
  onCancel,
  onApply,
}: {
  original: string;
  suggestion: CsvAiValueRepairSuccess;
  onCancel: () => void;
  onApply: (value: string) => string | null;
}) {
  const [applyError, setApplyError] = useState<string | null>(null);
  return (
    <div className="min-w-[12rem] space-y-2">
      <p className="luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
        AI suggestion
      </p>
      <p className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
        {original === "" ? "—" : original}
      </p>
      <p className="luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
        →
      </p>
      <p className="luxia-type-body-dense" style={{ color: "var(--luxia-text-primary)" }}>
        {suggestion.suggestedValue}
      </p>
      {suggestion.explanation ? (
        <p className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
          {suggestion.explanation}
        </p>
      ) : null}
      {applyError ? (
        <p className="luxia-type-caption" style={{ color: "var(--luxia-error-70)" }} role="alert">
          {applyError}
        </p>
      ) : null}
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant="outline" size="compact" onClick={onCancel}>
          Dismiss
        </Button>
        <Button
          type="button"
          variant="primary"
          size="compact"
          onClick={() => {
            const message = onApply(suggestion.suggestedValue);
            setApplyError(message);
          }}
        >
          Apply
        </Button>
      </div>
    </div>
  );
}

function validExamplesFor(file: CsvImportFileDraft, columnId: string): string[] {
  const column = file.columns.find((item) => item.id === columnId);
  if (column?.examples.length) return column.examples.slice(0, 3);
  return [];
}

function neighborValuesFor(file: CsvImportFileDraft, rowNumber: number): string[] {
  const record = file.parsed?.records.find((item) => item.rowNumber === rowNumber);
  if (!record) return [];
  return record.fields.filter((value) => value.trim() !== "").slice(0, 4);
}

export function similarIssueGroups(issues: DisplayCsvIssue[]): Array<{
  columnId: string;
  columnName: string;
  expected: string;
  issues: DisplayCsvIssue[];
}> {
  const open = issues.filter((issue) => issue.resolution === "open");
  const byColumn = new Map<string, DisplayCsvIssue[]>();
  for (const issue of open) {
    const list = byColumn.get(issue.columnId) ?? [];
    list.push(issue);
    byColumn.set(issue.columnId, list);
  }
  return [...byColumn.entries()]
    .map(([columnId, columnIssues]) => ({
      columnId,
      columnName: columnIssues[0]?.columnName ?? "",
      expected: columnIssues[0]?.expected ?? "",
      issues: columnIssues,
    }))
    .filter((group) => group.issues.length >= 2);
}

export function schemaPreviewRows(
  records: Array<{ rowNumber: number; fields: string[] }>,
  priorityRowNumbers: ReadonlySet<number>,
  limit = SCHEMA_PREVIEW_ROW_LIMIT,
): Array<{ rowNumber: number; fields: string[] }> {
  if (records.length <= limit) return records;
  const prioritized = records.filter((record) => priorityRowNumbers.has(record.rowNumber));
  const rest = records.filter((record) => !priorityRowNumbers.has(record.rowNumber));
  const preferred = [...prioritized.slice(0, limit), ...rest.slice(0, Math.max(0, limit - prioritized.length))];
  const seen = new Set<number>();
  return preferred
    .sort((a, b) => a.rowNumber - b.rowNumber)
    .filter((record) => {
      if (seen.has(record.rowNumber)) return false;
      seen.add(record.rowNumber);
      return true;
    })
    .slice(0, limit);
}

export function ColumnNameEditor({
  name,
  originalName,
  onSave,
}: {
  name: string;
  originalName?: string;
  onSave: (nextName: string) => string | null;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(name);
  const [error, setError] = useState<string | null>(null);
  const original = originalName && originalName !== name ? originalName : null;

  useEffect(() => {
    setDraft(name);
    setError(null);
    setEditing(false);
  }, [name]);

  function cancel() {
    setDraft(name);
    setError(null);
    setEditing(false);
  }

  function save() {
    const message = onSave(draft);
    if (message) {
      setError(message);
      return;
    }
    setError(null);
    setEditing(false);
  }

  if (!editing) {
    return (
      <div className="min-w-0">
        <button
          type="button"
          className="max-w-full truncate rounded-[4px] text-left underline-offset-2 outline-none hover:underline focus-visible:ring-2 focus-visible:ring-[var(--luxia-border-focus)]"
          style={{ color: "var(--luxia-text-primary)" }}
          title="Rename column"
          onClick={() => {
            setDraft(name);
            setError(null);
            setEditing(true);
          }}
        >
          {name}
        </button>
        {original ? (
          <p className="mt-1 luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
            Original: {original}
          </p>
        ) : null}
      </div>
    );
  }

  return (
    <div className="min-w-[10rem] space-y-2">
      <Input
        value={draft}
        onChange={(event) => {
          setDraft(event.target.value);
          setError(null);
        }}
        onKeyDown={(event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            save();
          }
          if (event.key === "Escape") {
            event.preventDefault();
            cancel();
          }
        }}
        autoComplete="off"
        aria-label="Working column name"
        aria-invalid={Boolean(error)}
        className="h-8"
        autoFocus
      />
      {error ? (
        <p className="luxia-type-caption" style={{ color: "var(--luxia-error-70)" }} role="alert">
          {error}
        </p>
      ) : original ? (
        <p className="luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
          Original: {original}
        </p>
      ) : null}
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant="outline" size="compact" onClick={cancel}>
          Cancel
        </Button>
        <Button type="button" variant="secondary" size="compact" onClick={save}>
          Save
        </Button>
      </div>
    </div>
  );
}

export function SchemaDataPreview({
  file,
  live,
  focusedColumnId,
  onTypeChange,
  onConfirmType,
  onRenameColumn,
  onSaveFix,
  onSaveFixes,
  onExclude,
  onUndo,
}: {
  file: CsvImportFileDraft;
  live: CsvValidationSummary;
  focusedColumnId: string | null;
  onTypeChange: (columnId: string, type: string) => void;
  onConfirmType: (columnId: string) => void;
  onRenameColumn: (columnId: string, nextName: string) => string | null;
  onSaveFix: (issue: CsvValidationIssue, value: string) => string | null;
  onSaveFixes: (fixes: Array<{ issue: CsvValidationIssue; value: string }>) => string | null;
  onExclude: (rowNumber: number) => void;
  onUndo: (rowNumber: number) => void;
}) {
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [aiBusyKey, setAiBusyKey] = useState<string | null>(null);
  const [aiNoticeKey, setAiNoticeKey] = useState<string | null>(null);
  const [aiNotice, setAiNotice] = useState<string | null>(null);
  const [aiSuggestion, setAiSuggestion] = useState<{
    key: string;
    issue: CsvValidationIssue;
    data: CsvAiValueRepairSuccess;
  } | null>(null);
  const [similarBusy, setSimilarBusy] = useState<string | null>(null);
  const [similarNotice, setSimilarNotice] = useState<string | null>(null);
  const [similarPreview, setSimilarPreview] = useState<{
    columnId: string;
    data: CsvAiSimilarRepairSuccess;
  } | null>(null);
  const [similarApplyError, setSimilarApplyError] = useState<string | null>(null);

  const skipped = useMemo(() => new Set(file.skipped), [file.skipped]);
  const openIssues: DisplayCsvIssue[] = live.issues.map((issue) => ({
    ...issue,
    resolution: "open",
  }));
  const invalidRowNumbers = useMemo(
    () => new Set(live.issues.map((issue) => issue.rowNumber)),
    [live.issues],
  );
  const records = file.parsed?.records ?? [];
  const priority = useMemo(() => {
    const next = new Set(invalidRowNumbers);
    for (const rowNumber of file.skipped) next.add(rowNumber);
    return next;
  }, [file.skipped, invalidRowNumbers]);
  const rows = schemaPreviewRows(records, priority);
  const issueByCell = useMemo(
    () => new Map(live.issues.map((issue) => [`${issue.rowNumber}:${issue.columnId}`, issue])),
    [live.issues],
  );
  const issueCountByColumn = useMemo(() => {
    const counts = new Map<string, number>();
    for (const issue of live.issues) {
      counts.set(issue.columnId, (counts.get(issue.columnId) ?? 0) + 1);
    }
    return counts;
  }, [live.issues]);
  const similarGroups = useMemo(() => similarIssueGroups(openIssues), [openIssues]);
  const hiddenIssueRows = Math.max(0, invalidRowNumbers.size - rows.filter((row) => invalidRowNumbers.has(row.rowNumber)).length);

  async function requestValueRepair(issue: CsvValidationIssue) {
    const key = `${issue.rowNumber}:${issue.columnId}`;
    setAiBusyKey(key);
    setAiNoticeKey(null);
    setAiNotice(null);
    setAiSuggestion(null);
    const column = file.columns.find((item) => item.id === issue.columnId);
    const result = await proposeCsvValueRepair({
      fileId: file.id,
      fileName: file.fileName,
      rowNumber: issue.rowNumber,
      rowIndex: issue.rowIndex,
      columnId: issue.columnId,
      columnName: issue.columnName,
      currentValue: issue.value,
      selectedType: column ? selectedColumnType(column) : issue.expected,
      neighborValues: neighborValuesFor(file, issue.rowNumber),
      validExamples: validExamplesFor(file, issue.columnId),
    });
    setAiBusyKey(null);
    if (result.status === "ok") {
      setAiSuggestion({ key, issue, data: result.data });
      return;
    }
    setAiNoticeKey(key);
    setAiNotice(result.message);
  }

  async function requestSimilar(group: ReturnType<typeof similarIssueGroups>[number]) {
    setSimilarBusy(group.columnId);
    setSimilarNotice(null);
    setSimilarPreview(null);
    setSimilarApplyError(null);
    const result = await proposeCsvSimilarRepairs({
      fileId: file.id,
      fileName: file.fileName,
      columnId: group.columnId,
      columnName: group.columnName,
      selectedType: group.expected,
      issues: group.issues.map((issue) => ({
        rowNumber: issue.rowNumber,
        currentValue: issue.value,
      })),
    });
    setSimilarBusy(null);
    if (result.status === "ok") {
      setSimilarPreview({ columnId: group.columnId, data: result.data });
      return;
    }
    setSimilarNotice(result.message);
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
          Schema & data preview
        </p>
        <p className="luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
          {records.length <= SCHEMA_PREVIEW_ROW_LIMIT
            ? `${records.length.toLocaleString()} row${records.length === 1 ? "" : "s"}`
            : `Showing ${rows.length.toLocaleString()} of ${records.length.toLocaleString()} rows`}
        </p>
      </div>
      {similarGroups.length > 0 ? (
        <div className="space-y-2">
          {similarGroups.map((group) => (
            <div key={group.columnId} className="flex flex-wrap items-center gap-2">
              <p className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                {group.columnName}: {group.issues.length.toLocaleString()} similar issues
              </p>
              <LuxiaAiButton
                disabled={similarBusy === group.columnId}
                onClick={() => void requestSimilar(group)}
              >
                {similarBusy === group.columnId
                  ? "Generating…"
                  : `Fix ${group.issues.length.toLocaleString()} similar issues with AI`}
              </LuxiaAiButton>
            </div>
          ))}
          {similarNotice ? (
            <p className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }} role="status">
              {similarNotice}
            </p>
          ) : null}
          {similarPreview ? (
            <div className="space-y-2">
              <p className="luxia-type-body-dense" style={{ color: "var(--luxia-text-primary)" }}>
                {similarPreview.data.proposedCount.toLocaleString()} safe fix
                {similarPreview.data.proposedCount === 1 ? "" : "es"} — review before applying.
              </p>
              {similarPreview.data.explanation ? (
                <p className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                  {similarPreview.data.explanation}
                </p>
              ) : null}
              {similarPreview.data.changes.length > 0 ? (
                <ul className="max-h-40 space-y-1 overflow-y-auto luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                  {similarPreview.data.changes.slice(0, 12).map((change) => (
                    <li key={`${similarPreview.columnId}:${change.rowNumber}`}>
                      Row {change.rowNumber}: {change.currentValue || "—"} → {change.suggestedValue || "—"}
                    </li>
                  ))}
                  {similarPreview.data.changes.length > 12 ? (
                    <li>
                      +{(similarPreview.data.changes.length - 12).toLocaleString()} more
                    </li>
                  ) : null}
                </ul>
              ) : null}
              {similarApplyError ? (
                <p className="luxia-type-caption" style={{ color: "var(--luxia-error-70)" }} role="alert">
                  {similarApplyError}
                </p>
              ) : null}
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="compact"
                  onClick={() => {
                    setSimilarPreview(null);
                    setSimilarApplyError(null);
                  }}
                >
                  Dismiss
                </Button>
                <Button
                  type="button"
                  variant="primary"
                  size="compact"
                  onClick={() => {
                    const fixes: Array<{ issue: CsvValidationIssue; value: string }> = [];
                    for (const change of similarPreview.data.changes) {
                      const issue = openIssues.find(
                        (item) =>
                          item.columnId === similarPreview.columnId
                          && item.rowNumber === change.rowNumber,
                      );
                      if (!issue) continue;
                      fixes.push({ issue, value: change.suggestedValue });
                    }
                    const message = onSaveFixes(fixes);
                    if (message) {
                      setSimilarApplyError(message);
                      return;
                    }
                    setSimilarPreview(null);
                    setSimilarApplyError(null);
                  }}
                >
                  Apply safe fixes
                </Button>
              </div>
            </div>
          ) : null}
        </div>
      ) : null}
      {hiddenIssueRows > 0 ? (
        <p className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
          {hiddenIssueRows.toLocaleString()} more row{hiddenIssueRows === 1 ? "" : "s"} with issues are not shown. Fix the column type or parsing first if most rows fail.
        </p>
      ) : null}
      {file.columns.length === 0 ? (
        <div className="luxia-settings-section-surface">
          <p className="luxia-type-body-dense" style={{ color: "var(--luxia-text-secondary)" }}>
            No columns were found in this file.
          </p>
        </div>
      ) : (
        <div className="luxia-settings-table-surface max-h-[min(28rem,52vh)] overflow-auto">
          <table className="w-full min-w-max border-collapse text-left">
            <thead>
              <tr className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                <th
                  className="sticky top-0 z-[1] border-b px-2 py-2 font-normal"
                  style={{
                    background: "var(--luxia-settings-section-bg)",
                    borderColor: "var(--luxia-settings-section-border)",
                  }}
                >
                  Row
                </th>
                {file.columns.map((col) => {
                  const issueCount = issueCountByColumn.get(col.id) ?? 0;
                  const needsReview = col.status === "needs-review";
                  const focused = focusedColumnId === col.id;
                  return (
                    <th
                      key={col.id}
                      className="sticky top-0 z-[1] min-w-[9.5rem] border-b px-2 py-2 align-top font-normal"
                      style={{
                        background: focused
                          ? "var(--luxia-settings-selected-bg)"
                          : "var(--luxia-settings-section-bg)",
                        borderColor: "var(--luxia-settings-section-border)",
                      }}
                    >
                      <div className="space-y-1.5">
                        <ColumnNameEditor
                          name={col.name}
                          originalName={col.originalName}
                          onSave={(nextName) => onRenameColumn(col.id, nextName)}
                        />
                        <Select
                          key={`${file.id}:${col.id}:type:${col.type}`}
                          value={selectedColumnType(col)}
                          onValueChange={(value) => {
                            if (value === col.type) return;
                            onTypeChange(col.id, value);
                          }}
                        >
                          <SelectTrigger size="sm" aria-label={`Type for ${col.name}`} className="min-w-[7.5rem]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {CSV_COLUMN_TYPES.map((type) => (
                              <SelectItem key={type} value={type}>
                                {type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {issueCount > 0 ? (
                          <p className="luxia-type-caption" style={{ color: "var(--luxia-warning-90)" }}>
                            ⚠ {issueCount.toLocaleString()} issue{issueCount === 1 ? "" : "s"}
                          </p>
                        ) : needsReview ? (
                          <p className="luxia-type-caption" style={{ color: "var(--luxia-warning-90)" }}>
                            Needs review
                          </p>
                        ) : (
                          <p className="luxia-type-caption" style={{ color: "var(--luxia-success-70)" }}>
                            Ready
                          </p>
                        )}
                        {needsReview ? (
                          <Button
                            type="button"
                            variant="secondary"
                            size="compact"
                            onClick={() => onConfirmType(col.id)}
                          >
                            Confirm type
                          </Button>
                        ) : null}
                      </div>
                    </th>
                  );
                })}
                <th
                  className="sticky top-0 z-[1] border-b px-2 py-2 font-normal"
                  style={{
                    background: "var(--luxia-settings-section-bg)",
                    borderColor: "var(--luxia-settings-section-border)",
                  }}
                >
                  Status
                </th>
                <th
                  className="sticky top-0 z-[1] border-b px-2 py-2 font-normal"
                  style={{
                    background: "var(--luxia-settings-section-bg)",
                    borderColor: "var(--luxia-settings-section-border)",
                  }}
                >
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const excluded = skipped.has(row.rowNumber);
                const rowIssues = live.issues.filter((issue) => issue.rowNumber === row.rowNumber);
                const invalid = !excluded && rowIssues.length > 0;
                const surface = excluded
                  ? issueRowSurface("skipped")
                  : invalid
                    ? issueRowSurface("open")
                    : { background: "transparent", statusLabel: "Ready", statusColor: "var(--luxia-success-70)" };
                const primaryIssue = rowIssues[0];
                const primaryKey = primaryIssue ? `${primaryIssue.rowNumber}:${primaryIssue.columnId}` : "";
                return (
                  <tr
                    key={row.rowNumber}
                    className="border-t luxia-type-caption"
                    style={{
                      borderColor: "var(--luxia-settings-row-divider)",
                      background: surface.background,
                      color: "var(--luxia-text-secondary)",
                    }}
                  >
                    <td className="whitespace-nowrap px-2 py-1.5 tabular-nums" style={{ color: "var(--luxia-text-primary)" }}>
                      {row.rowNumber}
                    </td>
                    {file.columns.map((column, cellIndex) => {
                      const value = file.overrides[row.rowNumber]?.[column.id] ?? row.fields[cellIndex] ?? "";
                      const issue = excluded ? undefined : issueByCell.get(`${row.rowNumber}:${column.id}`);
                      const cellKey = `${row.rowNumber}:${column.id}`;
                      const editing = Boolean(issue && editingKey === cellKey);
                      const suggestion = issue && aiSuggestion?.key === cellKey ? aiSuggestion : null;
                      return (
                        <td
                          key={cellKey}
                          className="max-w-[12rem] px-2 py-1.5 align-top"
                          title={value || undefined}
                          style={issue ? { background: "var(--luxia-opacity-error-08)" } : undefined}
                        >
                          {editing && issue ? (
                            <InlineValueFix
                              original={issue.value}
                              expected={issue.expected}
                              onCancel={() => setEditingKey(null)}
                              onSave={(next) => {
                                const message = onSaveFix(issue, next);
                                if (!message) setEditingKey(null);
                                return message;
                              }}
                            />
                          ) : suggestion && issue ? (
                            <AiSuggestionReview
                              original={issue.value}
                              suggestion={suggestion.data}
                              onCancel={() => setAiSuggestion(null)}
                              onApply={(next) => {
                                const message = onSaveFix(issue, next);
                                if (!message) setAiSuggestion(null);
                                return message;
                              }}
                            />
                          ) : issue ? (
                            <button
                              type="button"
                              className="max-w-full truncate rounded-[4px] text-left underline-offset-2 outline-none hover:underline focus-visible:ring-2 focus-visible:ring-[var(--luxia-border-focus)]"
                              style={{ color: "var(--luxia-error-70)" }}
                              title={`${value || "Empty"}. Click to edit.`}
                              onClick={() => setEditingKey(cellKey)}
                            >
                              {value === "" ? "—" : truncateCsvCell(value, 28)}
                            </button>
                          ) : (
                            <span className="block max-w-[12rem] truncate" title={value || undefined}>
                              {value === "" ? "—" : truncateCsvCell(value, 28)}
                            </span>
                          )}
                          {issue && aiNoticeKey === cellKey && aiNotice ? (
                            <p className="mt-1 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }} role="status">
                              {aiNotice}
                            </p>
                          ) : null}
                        </td>
                      );
                    })}
                    <td className="px-2 py-1.5 align-top">
                      <span className="inline-flex items-center gap-1.5" style={{ color: surface.statusColor }}>
                        <span
                          className="size-1.5 shrink-0 rounded-full"
                          style={{ background: surface.statusColor }}
                          aria-hidden
                        />
                        {surface.statusLabel}
                      </span>
                    </td>
                    <td className="px-2 py-1.5 align-top">
                      {excluded ? (
                        <Button type="button" variant="secondary" size="compact" onClick={() => onUndo(row.rowNumber)}>
                          Undo
                        </Button>
                      ) : (
                        <span className="inline-flex flex-col items-start gap-1.5">
                          {primaryIssue && editingKey !== primaryKey && aiSuggestion?.key !== primaryKey ? (
                            <LuxiaAiButton
                              disabled={aiBusyKey === primaryKey}
                              onClick={() => void requestValueRepair(primaryIssue)}
                            >
                              {aiBusyKey === primaryKey ? "Generating…" : "Fix with AI"}
                            </LuxiaAiButton>
                          ) : null}
                          <ExcludeRowButton onExclude={() => onExclude(row.rowNumber)} />
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function ExcludedRowsTable({
  issues,
  onUndo,
}: {
  issues: DisplayCsvIssue[];
  onUndo: (rowNumber: number) => void;
}) {
  if (issues.length === 0) {
    return (
      <p className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
        No excluded rows.
      </p>
    );
  }
  return (
    <div className="luxia-settings-table-surface max-h-[min(16rem,36vh)] overflow-auto">
      <table className="w-full border-collapse text-left">
        <thead>
          <tr className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
            <th className="px-3 py-2 font-normal">Row</th>
            <th className="px-3 py-2 font-normal">Value</th>
            <th className="px-3 py-2 font-normal">Status</th>
            <th className="px-3 py-2 font-normal">Action</th>
          </tr>
        </thead>
        <tbody>
          {issues.map((issue) => (
            <tr
              key={`${issue.rowNumber}:${issue.columnId}`}
              className="border-t luxia-type-caption"
              style={{
                borderColor: "var(--luxia-settings-row-divider)",
                background: "var(--luxia-warning-10)",
              }}
            >
              <td className="px-3 py-2 tabular-nums" style={{ color: "var(--luxia-text-primary)" }}>
                {issue.rowNumber}
              </td>
              <td className="max-w-[18rem] truncate px-3 py-2" style={{ color: "var(--luxia-text-secondary)" }} title={issue.value || undefined}>
                {issue.columnName !== "Row" ? `${issue.columnName}: ` : null}
                {issue.value === "" ? "—" : truncateCsvCell(issue.value, 40)}
              </td>
              <td className="px-3 py-2" style={{ color: "var(--luxia-warning-90)" }}>
                Excluded
              </td>
              <td className="px-3 py-2">
                <Button type="button" variant="secondary" size="compact" onClick={() => onUndo(issue.rowNumber)}>
                  Undo
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
