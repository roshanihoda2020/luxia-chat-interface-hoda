/**
 * Prototype Analytics filter catalog — replace with production tenant/org grants.
 *
 * This repository has Organization Admin, not a Platform Admin persona.
 * Settings → Analytics is Org Admin–gated. The page is titled platform-wide,
 * so Org Admins receive Tenant + Organization controls with “All” defaults.
 * Organization-scoped viewers get a locked current-organization field only.
 */

export const ANALYTICS_ALL_SCOPE_ID = "all";

export interface AnalyticsTenantOption {
  id: string;
  name: string;
}

export interface AnalyticsOrganizationOption {
  id: string;
  name: string;
  tenantId: string;
}

export const ANALYTICS_TENANTS: AnalyticsTenantOption[] = [
  { id: "tenant-luxia", name: "Luxia" },
  { id: "tenant-northwind", name: "Northwind" },
];

export const ANALYTICS_ORGANIZATIONS: AnalyticsOrganizationOption[] = [
  { id: "org-luxia-demo", name: "Luxia Demo", tenantId: "tenant-luxia" },
  { id: "org-luxia-ops", name: "Luxia Operations", tenantId: "tenant-luxia" },
  { id: "org-northwind-analytics", name: "Northwind Analytics", tenantId: "tenant-northwind" },
  { id: "org-northwind-support", name: "Northwind Support", tenantId: "tenant-northwind" },
];

/** Current prototype organization for the demo roster. */
export const ANALYTICS_HOME_ORGANIZATION = ANALYTICS_ORGANIZATIONS[0]!;

export type AnalyticsFilterAccess =
  | {
      mode: "platform";
      tenants: AnalyticsTenantOption[];
      organizations: AnalyticsOrganizationOption[];
    }
  | {
      mode: "organization";
      tenant: AnalyticsTenantOption;
      organization: AnalyticsOrganizationOption;
    };

export function resolveAnalyticsFilterAccess(orgRole: string | undefined | null): AnalyticsFilterAccess {
  if (orgRole === "Admin") {
    return {
      mode: "platform",
      tenants: ANALYTICS_TENANTS,
      organizations: ANALYTICS_ORGANIZATIONS,
    };
  }
  const tenant = ANALYTICS_TENANTS.find((item) => item.id === ANALYTICS_HOME_ORGANIZATION.tenantId)!;
  return {
    mode: "organization",
    tenant,
    organization: ANALYTICS_HOME_ORGANIZATION,
  };
}

export function organizationsForTenant(
  organizations: AnalyticsOrganizationOption[],
  tenantId: string,
): AnalyticsOrganizationOption[] {
  if (tenantId === ANALYTICS_ALL_SCOPE_ID) return organizations;
  return organizations.filter((item) => item.tenantId === tenantId);
}

export function analyticsScopeMatches(
  row: { tenantId: string; organizationId: string },
  tenantId: string,
  organizationId: string,
): boolean {
  if (organizationId !== ANALYTICS_ALL_SCOPE_ID) return row.organizationId === organizationId;
  if (tenantId !== ANALYTICS_ALL_SCOPE_ID) return row.tenantId === tenantId;
  return true;
}

export function analyticsScopeScale(tenantId: string, organizationId: string): number {
  if (organizationId !== ANALYTICS_ALL_SCOPE_ID) return 0.36;
  if (tenantId !== ANALYTICS_ALL_SCOPE_ID) return 0.62;
  return 1;
}
