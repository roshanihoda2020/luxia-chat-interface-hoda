import { useMemo, useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { Button } from "@/app/components/ui/button";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/app/components/ui/chart";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs";
import { DemoUserAvatar } from "@/app/features/permissions/demoUserAvatar";
import type { OrganizationUser } from "@/app/features/permissions/types";
import {
  LUXIA_SETTINGS_TAB_TRIGGER_CLASS,
  LUXIA_SETTINGS_TABLIST_CLASS,
} from "@/app/features/shared/luxiaSettingsUx";
import {
  CompactMetricTile,
  SettingsDialogSectionHeader,
  SettingsDialogSurface,
} from "../SettingsDialogBlocks";
import {
  filterPointsByRange,
  getOrganizationAnalyticsSnapshot,
  rangeHasActivity,
  resolveAnalyticsRange,
} from "./prototypeState";
import {
  ANALYTICS_ALL_SCOPE_ID,
  organizationsForTenant,
  resolveAnalyticsFilterAccess,
  type AnalyticsFilterAccess,
} from "./scope";
import type {
  AnalyticsDatePreset,
  PresenceStatus,
  SessionStatusFilter,
} from "./types";

const PRESENCE_CHART_CONFIG = {
  online: { label: "Online", color: "var(--luxia-success)" },
  idle: { label: "Idle", color: "var(--luxia-warning-50)" },
} satisfies ChartConfig;

const MINUTES_CHART_CONFIG = {
  minutes: { label: "Minutes", color: "var(--luxia-purple-60)" },
} satisfies ChartConfig;

const DATE_PRESETS: Array<{ id: AnalyticsDatePreset; label: string }> = [
  { id: "7d", label: "7 Days" },
  { id: "30d", label: "30 Days" },
  { id: "90d", label: "90 Days" },
  { id: "custom", label: "Custom" },
];

const SESSION_FILTERS: Array<{ id: SessionStatusFilter; label: string }> = [
  { id: "all", label: "All" },
  { id: "online", label: "Online" },
  { id: "idle", label: "Idle" },
];

const PAGE_SIZES = ["5", "10", "25"] as const;

function statusTone(status: PresenceStatus): { color: string; label: string } {
  if (status === "online") return { color: "var(--luxia-success-70)", label: "Online" };
  if (status === "idle") return { color: "var(--luxia-warning-90)", label: "Idle" };
  return { color: "var(--luxia-text-muted)", label: "Offline" };
}

function formatMinutes(value: number): string {
  return `${value.toLocaleString()} min`;
}

function formatLastSeen(iso: string): string {
  return formatDistanceToNow(new Date(iso), { addSuffix: true });
}

function DateRangeControls({
  preset,
  customStart,
  customEnd,
  onPreset,
  onCustomStart,
  onCustomEnd,
  idPrefix,
}: {
  preset: AnalyticsDatePreset;
  customStart: string;
  customEnd: string;
  onPreset: (value: AnalyticsDatePreset) => void;
  onCustomStart: (value: string) => void;
  onCustomEnd: (value: string) => void;
  idPrefix: string;
}) {
  const startId = `${idPrefix}-start-date`;
  const endId = `${idPrefix}-end-date`;
  return (
    <div className="flex shrink-0 flex-col items-end gap-2">
      <div className="flex flex-nowrap items-center gap-1" role="group" aria-label="Date range">
        {DATE_PRESETS.map((item) => (
          <Button
            key={item.id}
            type="button"
            size="compact"
            variant={preset === item.id ? "secondary" : "tertiary"}
            aria-pressed={preset === item.id}
            onClick={() => onPreset(item.id)}
          >
            {item.label}
          </Button>
        ))}
      </div>
      {preset === "custom" ? (
        <div className="flex flex-nowrap items-end justify-end gap-2">
          <div className="space-y-1">
            <Label htmlFor={startId} className="luxia-type-caption">
              Start Date
            </Label>
            <Input
              id={startId}
              type="date"
              value={customStart}
              onChange={(event) => onCustomStart(event.target.value)}
              className="h-8 min-h-8 w-[10.5rem]"
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor={endId} className="luxia-type-caption">
              End Date
            </Label>
            <Input
              id={endId}
              type="date"
              value={customEnd}
              onChange={(event) => onCustomEnd(event.target.value)}
              className="h-8 min-h-8 w-[10.5rem]"
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

function PresenceMetricCard({
  label,
  value,
  status,
}: {
  label: string;
  value: number;
  status?: PresenceStatus | "neutral";
}) {
  const tone =
    status === "online" || status === "idle" || status === "offline"
      ? statusTone(status)
      : { color: "var(--luxia-text-muted)", label };
  return (
    <div className="min-w-0 rounded-[var(--luxia-radius-12)] border border-[var(--luxia-settings-section-border,var(--luxia-border-default))] bg-[var(--luxia-settings-section-bg,var(--luxia-neutral-50))] px-3.5 py-3.5">
      <p className="mb-2 flex items-center gap-1.5 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
        <span className="size-1.5 shrink-0 rounded-full" style={{ background: tone.color }} aria-hidden />
        {label}
      </p>
      <p className="luxia-type-title-card tabular-nums leading-none" style={{ color: "var(--luxia-text-primary)" }}>
        {value.toLocaleString()}
      </p>
    </div>
  );
}

function ChartEmpty({ message }: { message: string }) {
  return (
    <div
      className="flex h-52 items-center justify-center rounded-[var(--luxia-radius-12)] border border-[var(--luxia-settings-section-border)] bg-[var(--luxia-settings-section-bg)] px-4"
      role="status"
    >
      <p className="luxia-type-body-dense" style={{ color: "var(--luxia-text-secondary)" }}>
        {message}
      </p>
    </div>
  );
}

function TableEmpty({ message }: { message: string }) {
  return (
    <p className="px-3 py-6 text-center luxia-type-body-dense" style={{ color: "var(--luxia-text-secondary)" }} role="status">
      {message}
    </p>
  );
}

function AnalyticsScopeFilterBar({
  access,
  tenantId,
  organizationId,
  onTenantChange,
  onOrganizationChange,
}: {
  access: AnalyticsFilterAccess;
  tenantId: string;
  organizationId: string;
  onTenantChange: (value: string) => void;
  onOrganizationChange: (value: string) => void;
}) {
  const organizationOptions =
    access.mode === "platform"
      ? organizationsForTenant(access.organizations, tenantId)
      : [access.organization];

  return (
    <SettingsDialogSurface className="mb-4 flex flex-wrap items-center gap-x-4 gap-y-2 px-3.5 py-2.5">
      <span
        className="shrink-0 luxia-type-label-small uppercase tracking-[0.06em]"
        style={{ color: "var(--luxia-text-muted)" }}
      >
        Filters:
      </span>
      {access.mode === "platform" ? (
        <div className="flex min-w-0 items-center gap-2">
          <Label htmlFor="analytics-tenant-filter" className="shrink-0 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
            Tenant
          </Label>
          <Select value={tenantId} onValueChange={onTenantChange}>
            <SelectTrigger
              id="analytics-tenant-filter"
              size="sm"
              aria-label="Tenant"
              className="h-8 min-h-8 w-[11.5rem]"
            >
              <SelectValue placeholder="All Tenants" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ANALYTICS_ALL_SCOPE_ID}>All Tenants</SelectItem>
              {access.tenants.map((tenant) => (
                <SelectItem key={tenant.id} value={tenant.id}>
                  {tenant.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      ) : null}
      <div className="flex min-w-0 items-center gap-2">
        <Label htmlFor="analytics-organization-filter" className="shrink-0 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
          Organization
        </Label>
        {access.mode === "platform" ? (
          <Select value={organizationId} onValueChange={onOrganizationChange}>
            <SelectTrigger
              id="analytics-organization-filter"
              size="sm"
              aria-label="Organization"
              className="h-8 min-h-8 w-[13.5rem]"
            >
              <SelectValue placeholder="All Organizations" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ANALYTICS_ALL_SCOPE_ID}>All Organizations</SelectItem>
              {organizationOptions.map((organization) => (
                <SelectItem key={organization.id} value={organization.id}>
                  {organization.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : (
          <div
            id="analytics-organization-filter"
            className="flex h-8 min-h-8 w-[13.5rem] items-center rounded-[var(--luxia-radius-8)] border border-[var(--luxia-border-default)] bg-[var(--luxia-surface)] px-3.5 luxia-type-input-value"
            style={{ color: "var(--luxia-text-primary)" }}
            aria-readonly="true"
          >
            {access.organization.name}
          </div>
        )}
      </div>
    </SettingsDialogSurface>
  );
}

export function OrganizationAnalyticsSection({ user }: { user: OrganizationUser }) {
  const access = useMemo(() => resolveAnalyticsFilterAccess(user.orgRole), [user.orgRole]);
  const [tenantId, setTenantId] = useState(() =>
    access.mode === "platform" ? ANALYTICS_ALL_SCOPE_ID : access.tenant.id,
  );
  const [organizationId, setOrganizationId] = useState(() =>
    access.mode === "platform" ? ANALYTICS_ALL_SCOPE_ID : access.organization.id,
  );
  const snapshot = useMemo(
    () => getOrganizationAnalyticsSnapshot({ tenantId, organizationId }),
    [tenantId, organizationId],
  );
  const [tab, setTab] = useState<"presence" | "avatar">("presence");
  const [presencePreset, setPresencePreset] = useState<AnalyticsDatePreset>("7d");
  const [avatarPreset, setAvatarPreset] = useState<AnalyticsDatePreset>("7d");
  const [presenceStart, setPresenceStart] = useState("");
  const [presenceEnd, setPresenceEnd] = useState("");
  const [avatarStart, setAvatarStart] = useState("");
  const [avatarEnd, setAvatarEnd] = useState("");
  const [sessionFilter, setSessionFilter] = useState<SessionStatusFilter>("all");
  const [sessionQuery, setSessionQuery] = useState("");
  const [pageSize, setPageSize] = useState(5);
  const [page, setPage] = useState(0);

  const presenceRange = resolveAnalyticsRange(presencePreset, presenceStart, presenceEnd);
  const avatarRange = resolveAnalyticsRange(avatarPreset, avatarStart, avatarEnd);
  const presencePoints = filterPointsByRange(snapshot.dailyPresence, presenceRange.start, presenceRange.end);
  const avatarPoints = filterPointsByRange(snapshot.dailyAvatarMinutes, avatarRange.start, avatarRange.end);
  const presenceActive = rangeHasActivity(presencePoints);
  const avatarActive = rangeHasActivity(avatarPoints);

  const filteredSessions = snapshot.activeSessions.filter((row) => {
    if (sessionFilter !== "all" && row.status !== sessionFilter) return false;
    const query = sessionQuery.trim().toLowerCase();
    if (!query) return true;
    return row.name.toLowerCase().includes(query) || row.userId.toLowerCase().includes(query);
  });
  const pageCount = Math.max(1, Math.ceil(filteredSessions.length / pageSize));
  const safePage = Math.min(page, pageCount - 1);
  const pagedSessions = filteredSessions.slice(safePage * pageSize, safePage * pageSize + pageSize);

  function handlePresencePreset(next: AnalyticsDatePreset) {
    setPresencePreset(next);
    if (next === "custom" && !presenceStart && !presenceEnd) {
      const range = resolveAnalyticsRange("7d", "", "");
      setPresenceStart(range.start.toISOString().slice(0, 10));
      setPresenceEnd(range.end.toISOString().slice(0, 10));
    }
  }

  function handleAvatarPreset(next: AnalyticsDatePreset) {
    setAvatarPreset(next);
    if (next === "custom" && !avatarStart && !avatarEnd) {
      const range = resolveAnalyticsRange("7d", "", "");
      setAvatarStart(range.start.toISOString().slice(0, 10));
      setAvatarEnd(range.end.toISOString().slice(0, 10));
    }
  }

  return (
    <>
      <SettingsDialogSectionHeader
        title="Analytics"
        description="Platform-wide user activity and telemetry"
      />
      <AnalyticsScopeFilterBar
        access={access}
        tenantId={tenantId}
        organizationId={organizationId}
        onTenantChange={(value) => {
          setTenantId(value);
          setPage(0);
          if (access.mode !== "platform") return;
          const nextOrgs = organizationsForTenant(access.organizations, value);
          if (
            organizationId !== ANALYTICS_ALL_SCOPE_ID
            && !nextOrgs.some((organization) => organization.id === organizationId)
          ) {
            setOrganizationId(ANALYTICS_ALL_SCOPE_ID);
          }
        }}
        onOrganizationChange={(value) => {
          setOrganizationId(value);
          setPage(0);
        }}
      />
      <Tabs
        value={tab}
        onValueChange={(value) => {
          if (value === "presence" || value === "avatar") setTab(value);
        }}
        className="w-full min-w-0 gap-4"
      >
        <TabsList
          aria-label="Analytics views"
          className={`${LUXIA_SETTINGS_TABLIST_CLASS} !min-w-0`}
          style={{ gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}
        >
          <TabsTrigger value="presence" className={LUXIA_SETTINGS_TAB_TRIGGER_CLASS}>
            User Presence
          </TabsTrigger>
          <TabsTrigger value="avatar" className={LUXIA_SETTINGS_TAB_TRIGGER_CLASS}>
            Avatar Usage
          </TabsTrigger>
        </TabsList>

        <TabsContent value="presence" className="m-0 space-y-5 outline-none">
          <section className="space-y-2">
            <h3 className="luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
              Real-Time Presence
            </h3>
            <div className="grid min-w-0 grid-cols-2 gap-3 @min-[720px]:grid-cols-4">
              <PresenceMetricCard label="Online" value={snapshot.presence.online} status="online" />
              <PresenceMetricCard label="Idle" value={snapshot.presence.idle} status="idle" />
              <PresenceMetricCard label="Offline" value={snapshot.presence.offline} status="offline" />
              <PresenceMetricCard label="Total Registered" value={snapshot.presence.totalRegistered} status="neutral" />
            </div>
          </section>

          <section className="space-y-2">
            <h3 className="luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
              Organization Usage
            </h3>
            <div className="grid min-w-0 grid-cols-2 gap-3 @min-[720px]:grid-cols-4">
              <CompactMetricTile label="Active Last Hour" value={snapshot.organizationUsage.lastHour} />
              <CompactMetricTile label="Active Today" value={snapshot.organizationUsage.today} />
              <CompactMetricTile label="Active This Week" value={snapshot.organizationUsage.thisWeek} />
              <CompactMetricTile label="Active This Month" value={snapshot.organizationUsage.thisMonth} />
            </div>
          </section>

          <section className="space-y-3">
            <div className="flex min-w-0 items-start justify-between gap-3">
              <h3 className="min-w-0 luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
                Daily Active Users
              </h3>
              <DateRangeControls
                idPrefix="analytics-presence"
                preset={presencePreset}
                customStart={presenceStart}
                customEnd={presenceEnd}
                onPreset={handlePresencePreset}
                onCustomStart={setPresenceStart}
                onCustomEnd={setPresenceEnd}
              />
            </div>
            {!presenceActive ? (
              <ChartEmpty message="No data available for this period." />
            ) : (
              <SettingsDialogSurface className="px-3 py-3">
                <ChartContainer config={PRESENCE_CHART_CONFIG} className="aspect-auto h-52 w-full">
                  <BarChart data={presencePoints} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                    <CartesianGrid vertical={false} stroke="var(--luxia-border-subtle)" />
                    <XAxis dataKey="label" tickLine={false} axisLine={false} interval="preserveStartEnd" minTickGap={24} />
                    <YAxis allowDecimals={false} tickLine={false} axisLine={false} width={28} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="online" stackId="presence" fill="var(--color-online)" maxBarSize={18} />
                    <Bar dataKey="idle" stackId="presence" fill="var(--color-idle)" maxBarSize={18} radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ChartContainer>
              </SettingsDialogSurface>
            )}
          </section>

          <section className="space-y-3">
            <div className="flex min-w-0 flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
                  Active Sessions
                </h3>
                <p className="mt-0.5 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                  {filteredSessions.length.toLocaleString()} live
                </p>
              </div>
              <div className="flex min-w-0 flex-wrap items-center gap-2">
                <div className="flex flex-wrap gap-1">
                  {SESSION_FILTERS.map((item) => (
                    <Button
                      key={item.id}
                      type="button"
                      size="compact"
                      variant={sessionFilter === item.id ? "secondary" : "tertiary"}
                      aria-pressed={sessionFilter === item.id}
                      onClick={() => {
                        setSessionFilter(item.id);
                        setPage(0);
                      }}
                    >
                      {item.label}
                    </Button>
                  ))}
                </div>
                <Input
                  value={sessionQuery}
                  onChange={(event) => {
                    setSessionQuery(event.target.value);
                    setPage(0);
                  }}
                  placeholder="Search users"
                  aria-label="Search users"
                  className="h-8 min-h-8 w-[12rem]"
                />
              </div>
            </div>
            <div className="luxia-settings-table-surface overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                    <th className="px-3 py-2 font-normal">User</th>
                    <th className="px-3 py-2 font-normal">Status</th>
                    <th className="px-3 py-2 font-normal">Last Seen</th>
                  </tr>
                </thead>
                <tbody>
                  {pagedSessions.length === 0 ? (
                    <tr>
                      <td colSpan={3}>
                        <TableEmpty
                          message={sessionFilter === "all" ? "No active users found" : "No active users found"}
                        />
                      </td>
                    </tr>
                  ) : (
                    pagedSessions.map((row) => {
                      const tone = statusTone(row.status);
                      return (
                        <tr
                          key={row.userId}
                          className="border-t"
                          style={{ borderColor: "var(--luxia-settings-row-divider)" }}
                        >
                          <td className="px-3 py-2.5">
                            <span className="flex min-w-0 items-center gap-2.5">
                              <DemoUserAvatar userId={row.userId} />
                              <span className="min-w-0">
                                <span className="block truncate luxia-type-body-dense" style={{ color: "var(--luxia-text-primary)" }}>
                                  {row.name}
                                </span>
                                <span className="block truncate luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
                                  {row.userId}
                                </span>
                              </span>
                            </span>
                          </td>
                          <td className="px-3 py-2.5">
                            <span className="inline-flex items-center gap-1.5 luxia-type-caption" style={{ color: tone.color }}>
                              <span className="size-1.5 shrink-0 rounded-full" style={{ background: tone.color }} aria-hidden />
                              {tone.label}
                            </span>
                          </td>
                          <td className="px-3 py-2.5 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                            {formatLastSeen(row.lastSeen)}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
              <div
                className="flex flex-wrap items-center justify-between gap-2 border-t px-3 py-2"
                style={{ borderColor: "var(--luxia-settings-row-divider)" }}
              >
                <p className="luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
                  {filteredSessions.length === 0
                    ? "0 rows"
                    : `${safePage * pageSize + 1}–${Math.min(filteredSessions.length, safePage * pageSize + pageSize)} of ${filteredSessions.length}`}
                </p>
                <div className="flex items-center gap-2">
                  <Select
                    value={String(pageSize)}
                    onValueChange={(value) => {
                      setPageSize(Number(value));
                      setPage(0);
                    }}
                  >
                    <SelectTrigger size="sm" aria-label="Rows per page" className="h-8 min-h-8 w-[5.5rem]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PAGE_SIZES.map((size) => (
                        <SelectItem key={size} value={size}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    type="button"
                    variant="tertiary"
                    size="compact"
                    disabled={safePage <= 0}
                    onClick={() => setPage((current) => Math.max(0, current - 1))}
                  >
                    Previous
                  </Button>
                  <Button
                    type="button"
                    variant="tertiary"
                    size="compact"
                    disabled={safePage >= pageCount - 1}
                    onClick={() => setPage((current) => Math.min(pageCount - 1, current + 1))}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </div>
          </section>
        </TabsContent>

        <TabsContent value="avatar" className="m-0 space-y-5 outline-none">
          <section className="space-y-2">
            <h3 className="luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
              Live Active Sessions
            </h3>
            <div className="luxia-settings-table-surface overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                    <th className="px-3 py-2 font-normal">Vidget</th>
                    <th className="px-3 py-2 font-normal">Avatar Type</th>
                    <th className="px-3 py-2 font-normal">Last Heartbeat</th>
                  </tr>
                </thead>
                <tbody>
                  {snapshot.liveAvatarSessions.length === 0 ? (
                    <tr>
                      <td colSpan={3}>
                        <TableEmpty message="No avatar usage data found" />
                      </td>
                    </tr>
                  ) : (
                    snapshot.liveAvatarSessions.map((row) => (
                      <tr
                        key={row.vidgetId}
                        className="border-t"
                        style={{ borderColor: "var(--luxia-settings-row-divider)" }}
                      >
                        <td className="px-3 py-2.5">
                          <span className="block truncate luxia-type-body-dense" style={{ color: "var(--luxia-text-primary)" }}>
                            {row.vidgetName}
                          </span>
                          <span className="block truncate luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
                            {row.vidgetId}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                          {row.avatarType}
                        </td>
                        <td className="px-3 py-2.5 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                          {formatLastSeen(row.lastHeartbeat)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </section>

          <section className="space-y-2">
            <h3 className="luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
              Avatar Session Time
            </h3>
            <div className="grid min-w-0 grid-cols-2 gap-3 @min-[720px]:grid-cols-4">
              <CompactMetricTile label="Last Hour" value={formatMinutes(snapshot.avatarMinutes.lastHour)} />
              <CompactMetricTile label="Today" value={formatMinutes(snapshot.avatarMinutes.today)} />
              <CompactMetricTile label="This Week" value={formatMinutes(snapshot.avatarMinutes.thisWeek)} />
              <CompactMetricTile label="This Month" value={formatMinutes(snapshot.avatarMinutes.thisMonth)} />
            </div>
          </section>

          <section className="space-y-3">
            <div className="flex min-w-0 items-start justify-between gap-3">
              <h3 className="min-w-0 luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
                Avatar Minutes Over Time
              </h3>
              <DateRangeControls
                idPrefix="analytics-avatar"
                preset={avatarPreset}
                customStart={avatarStart}
                customEnd={avatarEnd}
                onPreset={handleAvatarPreset}
                onCustomStart={setAvatarStart}
                onCustomEnd={setAvatarEnd}
              />
            </div>
            {!avatarActive ? (
              <ChartEmpty message="No data available for this period." />
            ) : (
              <SettingsDialogSurface className="px-3 py-3">
                <ChartContainer config={MINUTES_CHART_CONFIG} className="aspect-auto h-52 w-full">
                  <AreaChart data={avatarPoints} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                    <CartesianGrid vertical={false} stroke="var(--luxia-border-subtle)" />
                    <XAxis dataKey="label" tickLine={false} axisLine={false} interval="preserveStartEnd" minTickGap={24} />
                    <YAxis allowDecimals={false} tickLine={false} axisLine={false} width={36} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area
                      type="monotone"
                      dataKey="minutes"
                      stroke="var(--color-minutes)"
                      fill="var(--color-minutes)"
                      fillOpacity={0.16}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ChartContainer>
              </SettingsDialogSurface>
            )}
          </section>

          <section className="space-y-2">
            <h3 className="luxia-type-body-dense-strong" style={{ color: "var(--luxia-text-primary)" }}>
              Vidget Avatar Breakdown
            </h3>
            <div className="luxia-settings-table-surface overflow-x-auto">
              <table className="w-full min-w-[36rem] border-collapse text-left">
                <thead>
                  <tr className="luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                    <th className="px-3 py-2 font-normal">Vidget</th>
                    <th className="px-3 py-2 font-normal">Avatar Name</th>
                    <th className="px-3 py-2 font-normal">Avatar Type</th>
                    <th className="px-3 py-2 font-normal">Total Minutes</th>
                  </tr>
                </thead>
                <tbody>
                  {snapshot.vidgetBreakdown.length === 0 ? (
                    <tr>
                      <td colSpan={4}>
                        <TableEmpty message="No avatar usage data found" />
                      </td>
                    </tr>
                  ) : (
                    snapshot.vidgetBreakdown.map((row) => (
                      <tr
                        key={row.vidgetId}
                        className="border-t"
                        style={{ borderColor: "var(--luxia-settings-row-divider)" }}
                      >
                        <td className="px-3 py-2.5">
                          <span className="block truncate luxia-type-body-dense" style={{ color: "var(--luxia-text-primary)" }}>
                            {row.vidgetName}
                          </span>
                          <span className="block truncate luxia-type-caption" style={{ color: "var(--luxia-text-muted)" }}>
                            {row.vidgetId}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 luxia-type-body-dense" style={{ color: "var(--luxia-text-primary)" }}>
                          {row.avatarName}
                        </td>
                        <td className="px-3 py-2.5 luxia-type-caption" style={{ color: "var(--luxia-text-secondary)" }}>
                          {row.avatarType}
                        </td>
                        <td className="px-3 py-2.5 tabular-nums luxia-type-body-dense" style={{ color: "var(--luxia-text-primary)" }}>
                          {row.totalMinutes.toLocaleString()}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </TabsContent>
      </Tabs>
    </>
  );
}
