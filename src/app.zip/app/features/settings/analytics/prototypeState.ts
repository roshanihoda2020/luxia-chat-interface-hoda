/**
 * Organization Analytics prototype snapshot.
 *
 * There is no analytics backend, telemetry API, heartbeat service, or
 * session tracker in this repository. These values are a deterministic
 * Org Admin UX preview only. Do not treat them as production metrics.
 */
import { format, subDays } from "date-fns";
import { ORGANIZATION_USERS } from "@/app/features/permissions/data";
import { SEED_VIDGETS } from "@/app/features/vidgets/data";
import { VIDGET_AVATARS, VIDGET_EXPERIENCE_MODE_LABELS } from "@/app/features/vidgets/types";
import {
  ANALYTICS_ALL_SCOPE_ID,
  ANALYTICS_HOME_ORGANIZATION,
  ANALYTICS_ORGANIZATIONS,
  analyticsScopeMatches,
  analyticsScopeScale,
} from "./scope";
import type {
  ActiveSessionRow,
  DailyAvatarMinutesPoint,
  DailyPresencePoint,
  LiveAvatarSessionRow,
  OrganizationAnalyticsSnapshot,
  VidgetAvatarBreakdownRow,
} from "./types";

export interface AnalyticsScopeFilter {
  tenantId: string;
  organizationId: string;
}

export const ORGANIZATION_ANALYTICS_INTEGRATION = {
  available: false,
  source: "prototype" as const,
  missing:
    "No organization analytics API, telemetry store, or avatar session tracker exists in this repository.",
};

function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function isoMinutesAgo(minutes: number): string {
  return new Date(Date.now() - minutes * 60_000).toISOString();
}

function wave(seed: number, amplitude: number, floor: number): number {
  const value = floor + Math.round((Math.sin(seed) * 0.5 + 0.5) * amplitude);
  return Math.max(0, value);
}

function buildDailyPresence(today: Date): DailyPresencePoint[] {
  const points: DailyPresencePoint[] = [];
  for (let offset = 89; offset >= 0; offset -= 1) {
    const day = subDays(today, offset);
    // Keep the oldest 12 days empty so a far custom range can demonstrate no-data.
    const empty = offset >= 78;
    points.push({
      date: format(day, "yyyy-MM-dd"),
      label: format(day, "MMM d"),
      online: empty ? 0 : wave(offset * 0.37 + 1.2, 3, offset < 2 ? 2 : 1),
      idle: empty ? 0 : wave(offset * 0.51 + 2.4, 2, offset === 0 ? 1 : 0),
    });
  }
  return points;
}

function buildDailyAvatarMinutes(today: Date): DailyAvatarMinutesPoint[] {
  const points: DailyAvatarMinutesPoint[] = [];
  for (let offset = 89; offset >= 0; offset -= 1) {
    const day = subDays(today, offset);
    const empty = offset >= 78;
    points.push({
      date: format(day, "yyyy-MM-dd"),
      label: format(day, "MMM d"),
      minutes: empty ? 0 : wave(offset * 0.29 + 0.8, 420, offset < 1 ? 60 : 80),
    });
  }
  return points;
}

function avatarLabel(avatarId: string | undefined): string {
  return VIDGET_AVATARS.find((item) => item.id === avatarId)?.name ?? "Avatar";
}

function scaleCount(value: number, scale: number): number {
  if (value === 0) return 0;
  return Math.max(0, Math.round(value * scale));
}

const USER_ANALYTICS_SCOPE: Record<string, { tenantId: string; organizationId: string }> = {
  "user-01": { tenantId: "tenant-luxia", organizationId: "org-luxia-demo" },
  "user-02": { tenantId: "tenant-northwind", organizationId: "org-northwind-analytics" },
  "user-03": { tenantId: "tenant-luxia", organizationId: "org-luxia-ops" },
  "user-04": { tenantId: "tenant-northwind", organizationId: "org-northwind-support" },
  "user-05": { tenantId: "tenant-luxia", organizationId: "org-luxia-demo" },
};

const VIDGET_ANALYTICS_SCOPE: Record<string, { tenantId: string; organizationId: string }> = {
  "vidget-01": { tenantId: "tenant-luxia", organizationId: "org-luxia-demo" },
  "vidget-p2-01": { tenantId: "tenant-northwind", organizationId: "org-northwind-analytics" },
};

function userScope(userId: string): { tenantId: string; organizationId: string } {
  return USER_ANALYTICS_SCOPE[userId] ?? {
    tenantId: ANALYTICS_HOME_ORGANIZATION.tenantId,
    organizationId: ANALYTICS_HOME_ORGANIZATION.id,
  };
}

function vidgetScope(vidgetId: string, index: number): { tenantId: string; organizationId: string } {
  const mapped = VIDGET_ANALYTICS_SCOPE[vidgetId];
  if (mapped) return mapped;
  const organization = ANALYTICS_ORGANIZATIONS[index % ANALYTICS_ORGANIZATIONS.length]!;
  return { tenantId: organization.tenantId, organizationId: organization.id };
}

export function getOrganizationAnalyticsSnapshot(
  scope?: AnalyticsScopeFilter,
): OrganizationAnalyticsSnapshot {
  const tenantId = scope?.tenantId ?? ANALYTICS_ALL_SCOPE_ID;
  const organizationId = scope?.organizationId ?? ANALYTICS_ALL_SCOPE_ID;
  const scale = analyticsScopeScale(tenantId, organizationId);
  const today = startOfLocalDay(new Date());
  const roster = ORGANIZATION_USERS;
  const activeUsers = roster.filter((user) => user.status === "active");

  const allSessions: ActiveSessionRow[] = [
    {
      userId: "user-05",
      name: activeUsers.find((user) => user.id === "user-05")?.name ?? "User name 05",
      status: "online",
      lastSeen: isoMinutesAgo(1),
      ...userScope("user-05"),
    },
    {
      userId: "user-01",
      name: activeUsers.find((user) => user.id === "user-01")?.name ?? "User name 01",
      status: "online",
      lastSeen: isoMinutesAgo(6),
      ...userScope("user-01"),
    },
    {
      userId: "user-03",
      name: activeUsers.find((user) => user.id === "user-03")?.name ?? "User name 03",
      status: "idle",
      lastSeen: isoMinutesAgo(18),
      ...userScope("user-03"),
    },
    {
      userId: "user-02",
      name: activeUsers.find((user) => user.id === "user-02")?.name ?? "User name 02",
      status: "online",
      lastSeen: isoMinutesAgo(9),
      ...userScope("user-02"),
    },
    {
      userId: "user-04",
      name: activeUsers.find((user) => user.id === "user-04")?.name ?? "User name 04",
      status: "idle",
      lastSeen: isoMinutesAgo(22),
      ...userScope("user-04"),
    },
  ];
  const sessions = allSessions.filter((row) => analyticsScopeMatches(row, tenantId, organizationId));

  const published = SEED_VIDGETS.filter((item) => item.status === "published");
  const liveAvatarSessions: LiveAvatarSessionRow[] = published.slice(0, 2).map((vidget, index) => ({
    vidgetId: vidget.id,
    vidgetName: vidget.name,
    avatarType: VIDGET_EXPERIENCE_MODE_LABELS[vidget.experienceMode],
    lastHeartbeat: isoMinutesAgo(index === 0 ? 2 : 11),
    ...vidgetScope(vidget.id, index),
  })).filter((row) => analyticsScopeMatches(row, tenantId, organizationId));

  const vidgetBreakdown: VidgetAvatarBreakdownRow[] = published.map((vidget, index) => ({
    vidgetId: vidget.id,
    vidgetName: vidget.name,
    avatarName: avatarLabel(vidget.avatarId),
    avatarType: VIDGET_EXPERIENCE_MODE_LABELS[vidget.experienceMode],
    totalMinutes: [4820, 3901, 3383][index] ?? 1200,
    ...vidgetScope(vidget.id, index),
  })).filter((row) => analyticsScopeMatches(row, tenantId, organizationId));

  const online = sessions.filter((row) => row.status === "online").length;
  const idle = sessions.filter((row) => row.status === "idle").length;
  const totalRegistered = Math.max(sessions.length, scaleCount(roster.length, scale));
  const offline = Math.max(0, totalRegistered - online - idle);

  return {
    presence: {
      online,
      idle,
      offline,
      totalRegistered,
    },
    organizationUsage: {
      lastHour: Math.max(online, scaleCount(2, scale)),
      today: Math.max(sessions.length, scaleCount(4, scale)),
      thisWeek: Math.max(sessions.length, scaleCount(5, scale)),
      thisMonth: Math.max(sessions.length, scaleCount(5, scale)),
    },
    dailyPresence: buildDailyPresence(today).map((point) => ({
      ...point,
      online: scaleCount(point.online, scale),
      idle: scaleCount(point.idle, scale),
    })),
    activeSessions: sessions,
    liveAvatarSessions,
    avatarMinutes: {
      lastHour: scaleCount(60, scale),
      today: scaleCount(311, scale),
      thisWeek: scaleCount(2971, scale),
      thisMonth: scaleCount(12104, scale),
    },
    dailyAvatarMinutes: buildDailyAvatarMinutes(today).map((point) => ({
      ...point,
      minutes: scaleCount(point.minutes, scale),
    })),
    vidgetBreakdown,
  };
}

export function filterPointsByRange<T extends { date: string }>(
  points: T[],
  start: Date,
  end: Date,
): T[] {
  const startKey = format(startOfLocalDay(start), "yyyy-MM-dd");
  const endKey = format(startOfLocalDay(end), "yyyy-MM-dd");
  return points.filter((point) => point.date >= startKey && point.date <= endKey);
}

export function rangeHasActivity(
  points: Array<{ online?: number; idle?: number; minutes?: number }>,
): boolean {
  return points.some((point) => (point.online ?? 0) + (point.idle ?? 0) + (point.minutes ?? 0) > 0);
}

export function resolveAnalyticsRange(
  preset: "7d" | "30d" | "90d" | "custom",
  customStart: string,
  customEnd: string,
): { start: Date; end: Date } {
  const end = startOfLocalDay(new Date());
  if (preset === "7d") return { start: subDays(end, 6), end };
  if (preset === "30d") return { start: subDays(end, 29), end };
  if (preset === "90d") return { start: subDays(end, 89), end };
  const startDate = customStart ? startOfLocalDay(new Date(`${customStart}T00:00:00`)) : subDays(end, 6);
  const endDate = customEnd ? startOfLocalDay(new Date(`${customEnd}T00:00:00`)) : end;
  if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) {
    return { start: subDays(end, 6), end };
  }
  return startDate <= endDate ? { start: startDate, end: endDate } : { start: endDate, end: startDate };
}
