import { ChevronLeft } from "lucide-react";
import { LuxiaGalaxyIcon } from "@/assets/icons";
import { GALAXY_COLLAPSED_WIDTH, GALAXY_PANEL_OUTER_GAP } from "./constants";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/app/components/ui/tooltip";

const RAIL = {
  shell: "var(--luxia-galaxy-shell)",
  shellGradient: "var(--luxia-gradient-galaxy-panel)",
  shellBorder: "rgba(255, 255, 255, 0.06)",
  shellShadow: "var(--luxia-galaxy-shell-shadow)",
  iconWell: "var(--luxia-galaxy-surface-raised)",
  icon: "#FFFFFF",
  chevron: "rgba(255, 255, 255, 0.55)",
  btn: "rgba(255, 255, 255, 0.06)",
  focusRing: "0 0 0 2px rgba(142, 99, 235, 0.28)",
} as const;

export function GalaxyCollapsedRail({
  onExpand,
}: {
  status?: string;
  onExpand: () => void;
}) {
  return (
    <div
      className="flex h-full min-h-0 flex-shrink-0 flex-col self-stretch"
      style={{
        width: GALAXY_COLLAPSED_WIDTH + GALAXY_PANEL_OUTER_GAP * 2,
        padding: GALAXY_PANEL_OUTER_GAP,
        boxSizing: "border-box",
      }}
    >
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            onClick={onExpand}
            aria-label="Expand sidebar"
            aria-expanded={false}
            className="relative flex min-h-0 flex-1 flex-col items-center overflow-hidden outline-none focus-visible:outline-none"
            style={{
              width: GALAXY_COLLAPSED_WIDTH,
              minWidth: GALAXY_COLLAPSED_WIDTH,
              minHeight: 40,
              borderRadius: "var(--luxia-radius-24)",
              backgroundColor: RAIL.shell,
              backgroundImage: RAIL.shellGradient,
              border: `1px solid ${RAIL.shellBorder}`,
              boxShadow: RAIL.shellShadow,
              cursor: "pointer",
              transition: "filter 140ms ease, box-shadow 140ms ease",
            }}
            onFocus={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow = `${RAIL.shellShadow}, ${RAIL.focusRing}`;
            }}
            onBlur={(e) => {
              (e.currentTarget as HTMLElement).style.boxShadow = RAIL.shellShadow;
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.filter = "brightness(1.06)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.filter = "none";
            }}
            data-galaxy-panel="intelligence-collapsed"
          >
            <span
              className="mt-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-[8px]"
              style={{ background: RAIL.btn }}
              aria-hidden
            >
              <ChevronLeft size={16} style={{ color: RAIL.chevron }} strokeWidth={2.2} />
            </span>

            <span
              className="mt-3 flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-[10px]"
              style={{ background: RAIL.iconWell }}
              aria-hidden
            >
              <LuxiaGalaxyIcon size={18} style={{ color: RAIL.icon }} />
            </span>
          </button>
        </TooltipTrigger>
        <TooltipContent side="left">Expand sidebar</TooltipContent>
      </Tooltip>
    </div>
  );
}
